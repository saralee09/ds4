using System;

public class Aleatorios
{
	private Random random;

	public Aleatorios()
	{
		random = new Random();
	}

	public int GenerarNumeroEntre(int min, int max)
	{
		return random.Next(min, max + 1);
	}

	public int[] GenerarArregloNumerosEntre(int min, int max, int tama�o)
	{
		int[] arreglo = new int[tama�o];
		for (int i = 0; i < tama�o; i++)
		{
			arreglo[i] = GenerarNumeroEntre(min, max);
		}
		return arreglo;
	}

	public int[] GenerarArregloNumerosNoRepetidos(int min, int max, int tama�o)
	{
		if (tama�o > (max - min + 1))
		{
			throw new ArgumentException("El rango no puede contener suficientes n�meros �nicos para el tama�o solicitado.");
		}

		int[] arreglo = new int[tama�o];
		HashSet<int> numerosGenerados = new HashSet<int>();

		int contador = 0;
		while (contador < tama�o)
		{
			int numero = GenerarNumeroEntre(min, max);
			if (!numerosGenerados.Contains(numero))
			{
				numerosGenerados.Add(numero);
				arreglo[contador] = numero;
				contador++;
			}
		}
		return arreglo;
	}
}